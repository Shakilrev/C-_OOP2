﻿
namespace MedioSoft
{
    partial class manageProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.divider = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label_user_name = new System.Windows.Forms.Label();
            this.label_email_address = new System.Windows.Forms.Label();
            this.label_fname = new System.Windows.Forms.Label();
            this.label_password = new System.Windows.Forms.Label();
            this.label_phone = new System.Windows.Forms.Label();
            this.label_address = new System.Windows.Forms.Label();
            this.label_status = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.user_fname = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.address = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.user_phone = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.user_email = new System.Windows.Forms.TextBox();
            this.btn_updateProfile = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label_role = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(60, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "User Name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(60, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "Full Name :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(60, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "Password :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(60, 224);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 25);
            this.label4.TabIndex = 0;
            this.label4.Text = "Email Address :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(60, 259);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(177, 25);
            this.label5.TabIndex = 0;
            this.label5.Text = "Phone Number :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(60, 294);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 25);
            this.label6.TabIndex = 0;
            this.label6.Text = "Address :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(60, 329);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(132, 25);
            this.label7.TabIndex = 0;
            this.label7.Text = "User Status :";
            // 
            // divider
            // 
            this.divider.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(2)))), ((int)(((byte)(207)))));
            this.divider.Location = new System.Drawing.Point(64, 89);
            this.divider.Name = "divider";
            this.divider.Size = new System.Drawing.Size(480, 2);
            this.divider.TabIndex = 53;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(59, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(145, 32);
            this.label8.TabIndex = 52;
            this.label8.Text = "Profile Info";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_user_name
            // 
            this.label_user_name.AutoSize = true;
            this.label_user_name.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_user_name.Location = new System.Drawing.Point(258, 122);
            this.label_user_name.Name = "label_user_name";
            this.label_user_name.Size = new System.Drawing.Size(87, 21);
            this.label_user_name.TabIndex = 54;
            this.label_user_name.Text = "username";
            // 
            // label_email_address
            // 
            this.label_email_address.AutoSize = true;
            this.label_email_address.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.label_email_address.Location = new System.Drawing.Point(258, 226);
            this.label_email_address.Name = "label_email_address";
            this.label_email_address.Size = new System.Drawing.Size(161, 21);
            this.label_email_address.TabIndex = 55;
            this.label_email_address.Text = "rayhan@gmail.com";
            // 
            // label_fname
            // 
            this.label_fname.AutoSize = true;
            this.label_fname.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.label_fname.Location = new System.Drawing.Point(258, 156);
            this.label_fname.Name = "label_fname";
            this.label_fname.Size = new System.Drawing.Size(86, 21);
            this.label_fname.TabIndex = 56;
            this.label_fname.Text = "Full Name";
            // 
            // label_password
            // 
            this.label_password.AutoSize = true;
            this.label_password.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.label_password.Location = new System.Drawing.Point(258, 191);
            this.label_password.Name = "label_password";
            this.label_password.Size = new System.Drawing.Size(84, 21);
            this.label_password.TabIndex = 57;
            this.label_password.Text = "password";
            // 
            // label_phone
            // 
            this.label_phone.AutoSize = true;
            this.label_phone.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.label_phone.Location = new System.Drawing.Point(258, 261);
            this.label_phone.Name = "label_phone";
            this.label_phone.Size = new System.Drawing.Size(136, 21);
            this.label_phone.TabIndex = 58;
            this.label_phone.Text = "+8801643163478";
            // 
            // label_address
            // 
            this.label_address.AutoSize = true;
            this.label_address.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.label_address.Location = new System.Drawing.Point(258, 296);
            this.label_address.Name = "label_address";
            this.label_address.Size = new System.Drawing.Size(208, 21);
            this.label_address.TabIndex = 59;
            this.label_address.Text = "Nikunja 2, Khilkhet, Dhaka";
            // 
            // label_status
            // 
            this.label_status.AutoSize = true;
            this.label_status.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.label_status.Location = new System.Drawing.Point(258, 331);
            this.label_status.Name = "label_status";
            this.label_status.Size = new System.Drawing.Size(63, 21);
            this.label_status.TabIndex = 60;
            this.label_status.Text = "Active";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(2)))), ((int)(((byte)(207)))));
            this.panel1.Location = new System.Drawing.Point(659, 89);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(380, 2);
            this.panel1.TabIndex = 62;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(654, 50);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(180, 32);
            this.label16.TabIndex = 61;
            this.label16.Text = "Update Profile";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(656, 131);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(86, 21);
            this.label18.TabIndex = 77;
            this.label18.Text = "Full Name";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // user_fname
            // 
            this.user_fname.BackColor = System.Drawing.Color.White;
            this.user_fname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.user_fname.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.user_fname.Location = new System.Drawing.Point(659, 157);
            this.user_fname.Name = "user_fname";
            this.user_fname.Size = new System.Drawing.Size(180, 27);
            this.user_fname.TabIndex = 3;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(656, 203);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(72, 21);
            this.label19.TabIndex = 76;
            this.label19.Text = "Address";
            this.label19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // address
            // 
            this.address.BackColor = System.Drawing.SystemColors.Window;
            this.address.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.address.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.address.Location = new System.Drawing.Point(660, 228);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(380, 27);
            this.address.TabIndex = 4;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(856, 131);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 21);
            this.label20.TabIndex = 75;
            this.label20.Text = "Phone";
            this.label20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // user_phone
            // 
            this.user_phone.BackColor = System.Drawing.SystemColors.Window;
            this.user_phone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.user_phone.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.user_phone.Location = new System.Drawing.Point(859, 157);
            this.user_phone.Name = "user_phone";
            this.user_phone.Size = new System.Drawing.Size(180, 27);
            this.user_phone.TabIndex = 2;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(855, 272);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(51, 21);
            this.label21.TabIndex = 74;
            this.label21.Text = "Email";
            this.label21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // user_email
            // 
            this.user_email.BackColor = System.Drawing.SystemColors.Window;
            this.user_email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.user_email.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.user_email.Location = new System.Drawing.Point(859, 298);
            this.user_email.Name = "user_email";
            this.user_email.Size = new System.Drawing.Size(180, 27);
            this.user_email.TabIndex = 6;
            // 
            // btn_updateProfile
            // 
            this.btn_updateProfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(2)))), ((int)(((byte)(207)))));
            this.btn_updateProfile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_updateProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_updateProfile.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_updateProfile.ForeColor = System.Drawing.Color.White;
            this.btn_updateProfile.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_updateProfile.Location = new System.Drawing.Point(659, 349);
            this.btn_updateProfile.Name = "btn_updateProfile";
            this.btn_updateProfile.Size = new System.Drawing.Size(127, 38);
            this.btn_updateProfile.TabIndex = 72;
            this.btn_updateProfile.Text = "Update Profile";
            this.btn_updateProfile.UseVisualStyleBackColor = false;
            this.btn_updateProfile.Click += new System.EventHandler(this.btn_updateProfile_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(656, 272);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(82, 21);
            this.label23.TabIndex = 71;
            this.label23.Text = "Password";
            this.label23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // password
            // 
            this.password.BackColor = System.Drawing.SystemColors.Window;
            this.password.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.password.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.password.Location = new System.Drawing.Point(660, 297);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(180, 27);
            this.password.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(60, 363);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 25);
            this.label9.TabIndex = 78;
            this.label9.Text = "Role :";
            // 
            // label_role
            // 
            this.label_role.AutoSize = true;
            this.label_role.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.label_role.Location = new System.Drawing.Point(258, 366);
            this.label_role.Name = "label_role";
            this.label_role.Size = new System.Drawing.Size(62, 21);
            this.label_role.TabIndex = 79;
            this.label_role.Text = "Admin";
            // 
            // manageProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1100, 450);
            this.Controls.Add(this.label_role);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.user_fname);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.address);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.user_phone);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.user_email);
            this.Controls.Add(this.btn_updateProfile);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.password);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label_status);
            this.Controls.Add(this.label_address);
            this.Controls.Add(this.label_phone);
            this.Controls.Add(this.label_password);
            this.Controls.Add(this.label_fname);
            this.Controls.Add(this.label_email_address);
            this.Controls.Add(this.label_user_name);
            this.Controls.Add(this.divider);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimizeBox = false;
            this.Name = "manageProfile";
            this.Text = "manageProfile";
            this.Load += new System.EventHandler(this.manageProfile_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel divider;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label_user_name;
        private System.Windows.Forms.Label label_email_address;
        private System.Windows.Forms.Label label_fname;
        private System.Windows.Forms.Label label_password;
        private System.Windows.Forms.Label label_phone;
        private System.Windows.Forms.Label label_address;
        private System.Windows.Forms.Label label_status;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox user_fname;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox address;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox user_phone;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox user_email;
        private System.Windows.Forms.Button btn_updateProfile;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label_role;
    }
}